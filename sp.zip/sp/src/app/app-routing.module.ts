import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SpHomeComponent } from './sp-components/home/sp-home/sp-home.component';
import { UserLoginComponent } from './sp-components/login/user-login/user-login.component';
import { SpDashboardComponent } from './sp-components/dashboard/sp-dashboard/sp-dashboard.component';
import { UserSignComponent } from './sp-components/login/user-sign/user-sign.component';
import { UserLogoutComponent } from './sp-components/login/user-logout/user-logout.component';
import { SpHelpComponent } from './sp-components/home/sp-help/sp-help.component';
import { authGuard } from './sp-service/auth.guard';
import { NavbarComponent } from './sp-components/sp_navbar/navbar/navbar.component';
import { PageNotFoundComponent } from './sp-components/error_page/page-not-found/page-not-found.component';

const routes: Routes = [
  {
    path: '', redirectTo: 'login', pathMatch: 'full'
  },
  {
    path: 'login', component: UserLoginComponent
  },
  {
    path: 'sp-navbar', component: NavbarComponent, canActivate: [authGuard]
  },
  {
    path: 'sp-home', component: SpHomeComponent, canActivate: [authGuard]
  },
  {
    path: 'sign', component: UserSignComponent
  },
  {
    path: 'logout', component: UserLogoutComponent, canActivate: [authGuard]
  },
  {
    path: 'help', component: SpHelpComponent, canActivate: [authGuard]
  },
  {
    path: "dashboard", component: SpDashboardComponent, canActivate: [authGuard]
  },
  {
    path: '**', component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
