import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { SpModule } from './sp-modules/sp/sp.module';
import { HttpClient, HttpClientModule, provideHttpClient } from '@angular/common/http';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { UserLoginComponent } from './sp-components/login/user-login/user-login.component';
import { NavbarComponent } from './sp-components/sp_navbar/navbar/navbar.component';
import { SpHomeComponent } from './sp-components/home/sp-home/sp-home.component';
import { UserSignComponent } from './sp-components/login/user-sign/user-sign.component';
import { SpHelpComponent } from './sp-components/home/sp-help/sp-help.component';
import { UserLogoutComponent } from './sp-components/login/user-logout/user-logout.component';
 import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { PageNotFoundComponent } from './sp-components/error_page/page-not-found/page-not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    NavbarComponent,
    SpHomeComponent,
    UserSignComponent,
    SpHelpComponent,
    UserLogoutComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatSlideToggleModule,
    SpModule,
    MatToolbarModule,
    MatButtonModule,
    MatMenuModule,
    MatIconModule,
    RouterModule,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    HttpClientModule
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync(),
    provideHttpClient()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
