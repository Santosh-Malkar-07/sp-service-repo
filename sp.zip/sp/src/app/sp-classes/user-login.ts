export class UserLogin {
    constructor(
        public userName: String,
        public userPassword: String
    ) { }
}
