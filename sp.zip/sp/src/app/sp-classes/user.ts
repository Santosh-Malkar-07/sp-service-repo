export class User {
    mobile: string = '';
    name: string = '';
    panCardNumber: string = '';
    password: string = '';
    aadharCardNumber: string = '';
}
