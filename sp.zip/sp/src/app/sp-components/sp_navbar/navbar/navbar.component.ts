import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserLoginService } from '../../../sp-service/login/user-login.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent implements OnInit {

  constructor(private router: Router, private service: UserLoginService) { }


  ngOnInit(): void {
  }

  onHelp() {
    alert("Please login first")
  }

  viewOrder() {
    this.router.navigate(['/view-order-list']);
  }

  placeNewOrder() {
    this.router.navigate(['/place-new-order']);
  }
  logout() {
    this.service.logout();
    this.router.navigate(['/login']);
  }


}
