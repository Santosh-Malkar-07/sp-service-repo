import { Component } from '@angular/core';

@Component({
  selector: 'app-sp-help',
  templateUrl: './sp-help.component.html',
  styleUrl: './sp-help.component.css'
})
export class SpHelpComponent {

}
