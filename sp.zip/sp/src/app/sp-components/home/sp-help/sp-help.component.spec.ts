import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpHelpComponent } from './sp-help.component';

describe('SpHelpComponent', () => {
  let component: SpHelpComponent;
  let fixture: ComponentFixture<SpHelpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SpHelpComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SpHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
