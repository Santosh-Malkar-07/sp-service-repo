import { Component } from '@angular/core';

@Component({
  selector: 'app-sp-home',
  templateUrl: './sp-home.component.html',
  styleUrl: './sp-home.component.css'
})
export class SpHomeComponent {

}
