import { Component } from '@angular/core';

@Component({
  selector: 'app-place-new-order',
  templateUrl: './place-new-order.component.html',
  styleUrl: './place-new-order.component.css'
})
export class PlaceNewOrderComponent {

}
