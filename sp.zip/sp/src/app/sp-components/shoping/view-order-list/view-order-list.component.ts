import { Component } from '@angular/core';

@Component({
  selector: 'app-view-order-list',
  templateUrl: './view-order-list.component.html',
  styleUrl: './view-order-list.component.css'
})
export class ViewOrderListComponent {

}
