import { Component, inject, OnInit } from '@angular/core';
import { UserLogin } from '../../../sp-classes/user-login';
import { UserLoginService } from '../../../sp-service/login/user-login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrl: './user-login.component.css'
})
export class UserLoginComponent implements OnInit {

  userLogin: UserLogin = new UserLogin('', '');
  auth = inject(UserLoginService);

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    if ((this.userLogin.userName != null && this.userLogin.userPassword != null) && this.userLogin.userName != '' && this.userLogin.userPassword != '') {
      this.auth.getJwtToken(this.userLogin).subscribe(token => {
        if (!token.includes('User Exception')) {
          this.auth.login(token);
          this.router.navigate(['/sp-home']);
        } else {
          alert('Invalid Credentials')
        }

      }, (error) => alert(error));
    } else {
      alert("Username and Password should not be empty");
    }
  }
}
