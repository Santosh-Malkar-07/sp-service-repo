import { Component } from '@angular/core';

@Component({
  selector: 'app-user-records',
  templateUrl: './user-records.component.html',
  styleUrl: './user-records.component.css'
})
export class UserRecordsComponent {

}
