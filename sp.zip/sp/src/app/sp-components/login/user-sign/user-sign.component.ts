import { Component } from '@angular/core';

@Component({
  selector: 'app-user-sign',
  templateUrl: './user-sign.component.html',
  styleUrl: './user-sign.component.css'
})
export class UserSignComponent {

}
