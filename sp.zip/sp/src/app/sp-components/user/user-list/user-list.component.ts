import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../sp-service/users/user.service';
import { User } from '../../../sp-classes/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css',

})
export class UserListComponent implements OnInit {


  userList: User[] = [];
  user: User = new User();
  showDialog = false;
  editDialog = false;
  infoDialog = false;
  userId: string = '';
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
    console.log('Hello');
    this.userList = this.getAllUser();
    this.user = this.getUser("7030496752");
  }

  getUser(id: string) {
    this.userService.getUser(id).subscribe(user => {
      this.user = user;
    },
      (error) => { console.log("Error while getting data:", error) }
    );
    return this.user;
  }

  getAllUser() {

    this.userService.getAllUser().subscribe(user => {
      this.userList = user;
    },
      (error) => {
        console.log("Error while getting data: ", error);
      }
    );
    return this.userList;
  }

  editUser(id: string, user: User) {
    this.userId = id;
    this.user = this.getUser(id);
    this.editDialog = true;
  }



  editUserData(user: User) {
    this.userService.updateUser(this.userId, this.user).subscribe(response => {
      this.editDialog = false;
      this.infoDialog = true;
    }, (error) => { console.log("Error while updating User: ", error) });

  }

  deleteUser(id: string) {
    this.showDialog = true;
    this.userId = id;
  }

  createUser() {
    this.router.navigate(['/create-user']);
  }

  closeDialog() {
    this.showDialog = false;
    this.editDialog = false;
  }

  confirmAction() {
    this.userService.deleteUser(this.userId).subscribe(response => {
      this.showDialog = false;
      alert("Data deleted Successfully");
      this.getAllUser();
    }, (error) => {
      console.log("Error while deleting User: ", error)
    });
  }

  okAction() {
    this.infoDialog = false;
    this.getAllUser();
  }
}
