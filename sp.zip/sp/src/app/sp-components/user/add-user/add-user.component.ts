import { Component } from '@angular/core';
import { User } from '../../../sp-classes/user';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { UserService } from '../../../sp-service/users/user.service';
import { error } from 'console';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrl: './add-user.component.css'
})
export class AddUserComponent {

  constructor(private userService: UserService, private router: Router) { }

  user = new User();
  createUser(form: NgForm) {

    if (form.valid) {
      this.userService.storeUser(form.value).subscribe(data => {
        this.user = new User();
        this.router.navigate(['/user-list']);
      },(error) => console.log("User not Saved: ", error));
    } else {
      console.log("Form is Invalid");
    }


  }

  resetUser(userForm: any) {
    this.user = new User();
  }

  cancelUser() {
    this.router.navigate(['/user-list'])
  }

  hasValue(): boolean {
    return !!(this.user.name || this.user.mobile || this.user.aadharCardNumber || this.user.panCardNumber || this.user.password);
  }
}
