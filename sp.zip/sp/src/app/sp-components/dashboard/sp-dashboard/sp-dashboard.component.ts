import { Component } from '@angular/core';

@Component({
  selector: 'app-sp-dashboard',
  templateUrl: './sp-dashboard.component.html',
  styleUrl: './sp-dashboard.component.css'
})
export class SpDashboardComponent {

}
