import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddUserComponent } from '../../sp-components/user/add-user/add-user.component';
import { UserListComponent } from '../../sp-components/user/user-list/user-list.component';
import { ViewOrderListComponent } from '../../sp-components/shoping/view-order-list/view-order-list.component';
import { PlaceNewOrderComponent } from '../../sp-components/shoping/place-new-order/place-new-order.component';

const routes: Routes = [
  {
    path: 'user-list', component: UserListComponent
  },
  {
    path: 'create-user', component: AddUserComponent
  },
  {
    path: 'view-order-list', component: ViewOrderListComponent
  },
  {
    path: 'place-new-order', component: PlaceNewOrderComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SpRoutingModule { }
