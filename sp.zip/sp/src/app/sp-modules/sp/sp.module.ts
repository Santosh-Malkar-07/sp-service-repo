import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SpRoutingModule } from './sp-routing.module';
import { UserListComponent } from '../../sp-components/user/user-list/user-list.component';
import { AddUserComponent } from '../../sp-components/user/add-user/add-user.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatTableModule } from '@angular/material/table';
import { UserService } from '../../sp-service/users/user.service';
import { provideHttpClient } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { UserRecordsComponent } from '../../sp-components/login/user-records/user-records.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { ViewOrderListComponent } from '../../sp-components/shoping/view-order-list/view-order-list.component';
import { PlaceNewOrderComponent } from '../../sp-components/shoping/place-new-order/place-new-order.component';
import { SpDashboardComponent } from '../../sp-components/dashboard/sp-dashboard/sp-dashboard.component';


@NgModule({
  declarations: [
    UserListComponent,
    AddUserComponent,
    UserRecordsComponent,
    ViewOrderListComponent,
    PlaceNewOrderComponent,
    SpDashboardComponent
  ],
  imports: [
    CommonModule,
    SpRoutingModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatTableModule,
    RouterModule,
    FormsModule,
    MatToolbarModule,
    MatMenuModule
  ],
  exports: [UserListComponent, AddUserComponent],
  providers: [
    provideHttpClient(),
    UserService
  ]
})
export class SpModule { }
