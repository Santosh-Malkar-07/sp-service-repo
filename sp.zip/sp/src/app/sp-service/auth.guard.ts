import { CanActivateFn, Router } from '@angular/router';
import { UserService } from './users/user.service';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (route, state) => {


  var isLoggedIn: Boolean = false;
  if (typeof window !== 'undefined') {
    isLoggedIn = !!window.localStorage.getItem('token');

  }

  if (isLoggedIn) {
    return true;
  } else {
    const router = inject(Router);
    //router.navigate(['/login']);
    return false;
  }


};