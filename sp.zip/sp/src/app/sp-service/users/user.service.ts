import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../../sp-classes/user';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  private url = "http://localhost:8080/user/";

  constructor(private http: HttpClient) { }

  storeUser(user: User): Observable<User> {
    return this.http.post<User>(this.url + "storeUser", user);
  }

  /* Method to get user record based on id. */
  getUser(id: string): Observable<User> {
    return this.http.get<User>(this.url + "getUser/" + id);
  }

  /* Method to get all user record*/
  getAllUser(): Observable<User[]> {

    return this.http.get<User[]>(this.url + "getUsers");
  }

  updateUser(id: string, user: User): Observable<User> {
    return this.http.patch<User>(this.url + "updateUser/" + id, user);
  }

  deleteUser(id: string): Observable<void> {
    return this.http.delete<void>(this.url + "deleteUser/" + id);
  }
}
